package com.stepdefinition;

import java.net.URL;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class modistaApplication {
	WebDriver driver;

	@BeforeClass
	public void setUp() throws Exception {
		// Set up desired capabilities and pass the Android app-activity and app-package
		// to Appium
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("BROWSER_NAME", "Android");
		capabilities.setCapability("VERSION", "9.0");
		capabilities.setCapability("deviceName", "Emulator");
		capabilities.setCapability("platformName", "Android");

		capabilities.setCapability("appPackage", "com.modistabox");
		// This package name of your app (you can get it from apk info app)
		capabilities.setCapability("appActivity", "com.modistabox.mainActivity"); // This is Launcher activity of your
																					// application, it will launch the
																					// application (you can get it from
																					// apk info app)
		// Create RemoteWebDriver instance and connect to the Appium server
		// It will launch the Modistabox App in Android Device using the configurations
		// specified in Desired Capabilities
		driver = new RemoteWebDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);

	}

	@Test

	public void testCal() {
		try {
			/*
			 * a. Account should be already created. b. User profiles details should be
			 * completely filled.
			 */
			driver.findElement(By.id("User_name")).sendKeys("Abc123@gamil.com");
			driver.findElement(By.id("Password")).sendKeys("********");
			Thread.sleep(5000);
			// The Following pop Up Can occur at any time after launching the APP. Please
			// Handle a
			// condition to Hide this pop up -Click on �No Thanks� button.)
			driver.findElement(By.name("NO THANKS")).click();
			// Click On Add New Look button and select Gallery.
			driver.findElement(By.id("Add")).clear();
			driver.findElement(By.name("Gallery")).clear();
			// It will open gallery
			driver.findElement(By.xpath("//example.image 7[@clickable=�True�]")).click();
			// It will select model image from gallery.
			driver.findElement(By.name("NEXT")).click();
			// It will click Next button
			driver.findElement(By.xpath("//Image Name with index value�]")).click();
			// Click on add details
			driver.findElement(By.name("Add details")).click();
			/*
			 * Click On �Add details� the Fill all the Information by selecting dropdowns
			 * and Enter a Comment and click on the Save button.
			 */
			// Click on dropdown to open list.
			driver.findElement(By.id("Category")).click();
			// Select item "Boots" from drop down list.
			driver.findElement(By.name("Boots")).click();
			driver.findElement(By.id("Color/Pattern")).click();
			driver.findElement(By.name("Black")).click();
			driver.findElement(By.id("Brand")).click();
			driver.findElement(By.name("Nike")).click();
			driver.findElement(By.id("Looks")).click();
			driver.findElement(By.name("Modest")).click();
			driver.findElement(By.id("Save")).click();
			// Verify that the Tagged selections are appearing on the Look Image.
			String expected = "Nike";
			String actual = driver.findElement(By.id("Tag")).getText();
			Assert.assertTrue(expected.equalsIgnoreCase(actual), "Tag Mismatch!");
			// Click On Next button at the bottom.
			driver.findElement(By.name("Next")).click();
			// Enter A Comment for a look.
			driver.findElement(By.name("Comments")).sendKeys("Party Wear");
			// Click on Publish Look.
			driver.findElement(By.name("Publish Look")).click();
			Map<String, Object> args = Map.of("text", "Your look has been posted Successfully", "isRegexp", false);
			((RemoteWebDriver) driver).executeScript("mobile: isToastVisible", args);

			// Go to profile Looks and verify the new look is posted.
			driver.findElement(By.name("Profile")).click();
			/*
			 * Click on the look posted and verify if the same look is opening with Added
			 * Tag. Also verify that the Comments entered at step no. 9 is matching the
			 */

			driver.findElement(By.name("Looks")).click();
			String expected1 = "Nike";
			String actual1 = driver.findElement(By.id("Tag")).getText();
			Assert.assertTrue(expected.equalsIgnoreCase(actual), "Tag Mismatch!");

			String Comment1 = "Party Wear";
			String comment2 = driver.findElement(By.id("Tag_Comments")).getText();
			Assert.assertTrue(expected.equalsIgnoreCase(actual), "Tag Mismatch!");

			/*
			 * like the look by clicking on the Heart icon below the Look Image. Verify the
			 * count is increased and the color of the heart button is changed to Red.
			 */

			driver.findElement(By.name("Love_symbol")).click();
			WebElement elem = driver.findElement(By.id("by-id"));
			if (elem.getCssValue("color").contentEquals("Red")) {
				System.out.println("Color changed to Red");
				int count = 0;
				int count1 = count + 1;
				System.out.println("count1");
			}

			else {
				System.out.println("Color not Changed");
			}

//Click on the image to Tag products, and select the tag.

		}

		catch (Exception e) {
			System.out.println(e.getMessage());

		}
		
		finally {
			System.out.println("Exit the Task");
		}
	}
}
